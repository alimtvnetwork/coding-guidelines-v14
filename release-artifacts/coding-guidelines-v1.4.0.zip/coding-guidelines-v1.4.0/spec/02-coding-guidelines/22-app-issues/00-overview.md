# App Issues

**Version:** 3.1.0  
**Updated:** 2026-04-16

---

## Overview

App-specific issue analysis, root cause analysis, bug documentation, and solution guidance. This folder tracks problems encountered during application development, their diagnosis, and their resolution.

---

## Placement Rule

Any content that analyzes bugs, failures, root causes, or fixes for application-level work belongs here. General coding principle violations or cross-cutting concerns belong in the core fundamentals range (01–20).

---

## Contents

_No content yet. Add app issue analyses as numbered files within this folder._

---

## Cross-References

| Reference | Location |
|-----------|----------|
| App Specs | [../21-app/00-overview.md](../21-app/00-overview.md) |
| Coding Guidelines Spec | [../00-overview.md](../00-overview.md) |
